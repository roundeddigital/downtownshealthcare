<?php
echo count($_POST);