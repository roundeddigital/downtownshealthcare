<?php

if (!defined('EWPT_PLUGIN_SLUG')) define( 'EWPT_PLUGIN_SLUG', 'envato-wordpress-toolkit' );

require_once realpath(dirname(__FILE__)) . '/includes/class-envato-api.php';
//require_once realpath(dirname(__FILE__)) . '/includes/class-wp-upgrader.php';
