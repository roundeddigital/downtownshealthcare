<div>
  <h1>Setup complete</h1>
  <p>Uncode was successfully installed!</p>
</div>
<input type='hidden' name='install' value='true'>
<div class='text-right'>
    <input class="btn btn-primary" type='submit' value='Go to Dashboard'>
</div>
