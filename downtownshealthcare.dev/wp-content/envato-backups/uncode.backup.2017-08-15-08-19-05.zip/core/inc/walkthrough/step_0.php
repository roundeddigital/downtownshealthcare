<h1>Activate Theme</h1>
<p>Let's install Uncode!</p>
<input type='hidden' name='step' value="<?php echo ($step + 1); ?>">

<div class="text-right">
  <input class="btn btn-primary" type='submit' value='Next'>
</div>
