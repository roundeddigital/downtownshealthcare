<h1>Help and Support</h1>
<input type='hidden' name='step' value="<?php echo ($step + 1); ?>">
<div class="text-right">
  <input class="btn btn-primary" type='submit' value='Next'>
</div>
